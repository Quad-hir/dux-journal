import { describe, expect, it } from "vitest";
import {
  DEFAULT_RULES, calculateAccountSnapshot, calculatePlannedRR, closeTrade,
  countClosedTrade, createAccount, createCycle, prepareTrade, recordFill,
  validateAndApprove, placeOrder, type Checklist, type Trade,
} from "../src/engine";

const allChecked: Checklist = {
  strategyConfirmed: true, entryConfirmation: true, validInvalidationLevel: true,
  positionSizeCalculated: true, newsAndSessionChecked: true, exitPlanSaved: true,
  riskIsAffordable: true,
};
function makeTrade(account = createAccount("USD", 1000), direction: "LONG" | "SHORT" = "LONG"): Trade {
  const input = {
    id: "trade-1", cycleId: "cycle-1", pair: "EURUSD", direction,
    orderType: "LIMIT" as const, timeframe: "H4", setupDate: "2026-10-18",
    entry: 1.1, stopLoss: direction === "LONG" ? 1.09 : 1.11,
    takeProfit: direction === "LONG" ? 1.13 : 1.07,
    plannedRiskCash: 10, positionSize: 1000, rationale: "H4 setup with confirmation",
    checklist: allChecked, screenshotRef: undefined,
  };
  return prepareTrade(input, account, DEFAULT_RULES, "2026-10-18T09:00:00.000Z");
}

describe("Dux Journal engine", () => {
  it("calculates 1:3 RR for long and short setups", () => {
    expect(calculatePlannedRR(makeTrade())).toBeCloseTo(3);
    expect(calculatePlannedRR(makeTrade(createAccount("USD", 1000), "SHORT"))).toBeCloseTo(3);
  });
  it("accepts reward-to-risk ratios of 1:3 and higher, including 1:3.5", () => {
    const account = createAccount("USD", 1000);
    const trade = makeTrade(account);
    trade.takeProfit = 1.135; // 1:3.5 RR with 0.01 risk distance
    const prepared = prepareTrade({
      id: trade.id, cycleId: trade.cycleId, pair: trade.pair, direction: trade.direction,
      orderType: trade.orderType, timeframe: trade.timeframe, setupDate: trade.setupDate,
      entry: trade.entry, stopLoss: trade.stopLoss, takeProfit: 1.135,
      plannedRiskCash: trade.plannedRiskCash, positionSize: trade.positionSize,
      rationale: trade.rationale, screenshotRef: trade.screenshotRef, checklist: trade.checklist,
    }, account);
    expect(prepared.plannedRR).toBeCloseTo(3.5);
    expect(prepared.violations.some(v => v.includes("below the minimum 1:3"))).toBe(false);
    expect(prepared.violations).toHaveLength(0);
  });
  it("rejects reward-to-risk ratios below 1:3", () => {
    const account = createAccount("USD", 1000);
    const trade = makeTrade(account);
    trade.takeProfit = 1.129; // 1:2.9 RR
    const prepared = prepareTrade({
      id: trade.id, cycleId: trade.cycleId, pair: trade.pair, direction: trade.direction,
      orderType: trade.orderType, timeframe: trade.timeframe, setupDate: trade.setupDate,
      entry: trade.entry, stopLoss: trade.stopLoss, takeProfit: 1.129,
      plannedRiskCash: trade.plannedRiskCash, positionSize: trade.positionSize,
      rationale: trade.rationale, screenshotRef: trade.screenshotRef, checklist: trade.checklist,
    }, account);
    expect(prepared.violations.some(v => v.includes("below the minimum 1:3"))).toBe(true);
  });

  it("blocks risk above 1% of fixed starting balance", () => {
    const account = createAccount("USD", 1000);
    const trade = makeTrade(account);
    trade.plannedRiskCash = 10.01;
    expect(trade).toBeDefined();
    expect(validateAndApprove(trade, account).status).toBe("REVIEW_REQUIRED");
  });
  it("requires confirmed fill before closing and counts a qualifying trade once", () => {
    const account = createAccount("USD", 1000);
    const cycle = createCycle("2026-10-18T09:00:00.000Z");
    const trade = makeTrade(account);
    validateAndApprove(trade, account);
    placeOrder(trade);
    recordFill(trade, { price: 1.1, quantity: 1, actualInitialRiskCash: 10 });
    closeTrade(trade, { exitPrice: 1.13, grossPnL: 30, costs: 1, reason: "TAKE_PROFIT" });
    countClosedTrade(cycle, trade);
    countClosedTrade(cycle, trade);
    expect(cycle.qualifyingClosedTrades).toBe(1);
    expect(trade.netPnL).toBe(29);
    expect(trade.realisedR).toBeCloseTo(2.9);
  });
  it("keeps floating P/L separate from realised balance", () => {
    const account = createAccount("USD", 1000);
    const trade = makeTrade(account);
    validateAndApprove(trade, account);
    placeOrder(trade);
    recordFill(trade, { price: 1.1, quantity: 1, actualInitialRiskCash: 10 });
    const snap = calculateAccountSnapshot(account, [trade], { [trade.id]: 5 });
    expect(snap.realisedBalance).toBe(1000);
    expect(snap.equity).toBe(1005);
  });
});
