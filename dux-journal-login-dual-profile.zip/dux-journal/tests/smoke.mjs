import assert from 'node:assert/strict';
import {
  DEFAULT_RULES, calculateAccountSnapshot, calculatePlannedRR, closeTrade,
  countClosedTrade, createAccount, createCycle, prepareTrade, recordFill,
  validateAndApprove, placeOrder,
} from '../src/engine.ts';

const checklist = {
  strategyConfirmed: true, entryConfirmation: true, validInvalidationLevel: true,
  positionSizeCalculated: true, newsAndSessionChecked: true, exitPlanSaved: true,
  riskIsAffordable: true,
};
const account = createAccount('USD', 1000, '2026-10-18T09:00:00.000Z');
const cycle = createCycle('2026-10-18T09:00:00.000Z');
const trade = prepareTrade({
  id:'smoke-1', cycleId:cycle.id, pair:'EURUSD', direction:'LONG', orderType:'LIMIT', timeframe:'H4',
  setupDate:'2026-10-18', entry:1.1, stopLoss:1.09, takeProfit:1.13, plannedRiskCash:10,
  positionSize:1, rationale:'H4 demand with confirmation', checklist,
}, account, DEFAULT_RULES, '2026-10-18T09:00:00.000Z');
assert.equal(Math.round(calculatePlannedRR(trade)*100)/100, 3);
assert.deepEqual(trade.violations, []);
validateAndApprove(trade, account, DEFAULT_RULES, '2026-10-18T09:01:00.000Z');
assert.equal(trade.status, 'VALIDATED');
placeOrder(trade, '2026-10-18T09:02:00.000Z');
assert.equal(trade.status, 'PENDING');
recordFill(trade, {price:1.1, quantity:1, actualInitialRiskCash:10, at:'2026-10-18T09:03:00.000Z'}, account);
closeTrade(trade, {exitPrice:1.13, grossPnL:30, costs:1, reason:'TAKE_PROFIT', at:'2026-10-18T10:00:00.000Z'});
countClosedTrade(cycle, trade, '2026-10-18T10:01:00.000Z');
countClosedTrade(cycle, trade, '2026-10-18T10:02:00.000Z');
assert.equal(cycle.qualifyingClosedTrades, 1, 'duplicate counting must be prevented');
assert.equal(trade.netPnL, 29);
assert.equal(trade.realisedR, 2.9);
const snap = calculateAccountSnapshot(account, [trade]);
assert.equal(snap.realisedBalance, 1029);
assert.equal(snap.equity, 1029);

const tooRisky = prepareTrade({
  id:'smoke-2', cycleId:cycle.id, pair:'XAUUSD', direction:'LONG', orderType:'LIMIT', timeframe:'H4',
  setupDate:'2026-10-18', entry:100, stopLoss:90, takeProfit:130, plannedRiskCash:10.01,
  rationale:'test', checklist,
}, account, DEFAULT_RULES);
validateAndApprove(tooRisky, account);
assert.equal(tooRisky.status, 'REVIEW_REQUIRED', 'risk above 1% must be blocked');

console.log('Dux Journal engine smoke tests passed.');

const actualRiskBreach = prepareTrade({
  id:'smoke-3', cycleId:cycle.id, pair:'GBPUSD', direction:'LONG', orderType:'LIMIT', timeframe:'H4',
  setupDate:'2026-10-18', entry:1.1, stopLoss:1.09, takeProfit:1.13, plannedRiskCash:10,
  rationale:'valid planned setup', checklist,
}, account, DEFAULT_RULES);
validateAndApprove(actualRiskBreach, account);
placeOrder(actualRiskBreach);
recordFill(actualRiskBreach, {price:1.101, quantity:1, actualInitialRiskCash:10.5}, account);
assert.equal(actualRiskBreach.qualifiesForTest, false, 'actual risk above the cap must disqualify a trade');
assert.ok(actualRiskBreach.violations.some(v=>v.includes('Actual initial risk exceeds')));
console.log('Actual-fill risk-cap check passed.');
